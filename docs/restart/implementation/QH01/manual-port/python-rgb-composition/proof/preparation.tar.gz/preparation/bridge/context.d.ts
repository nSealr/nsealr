import { type LocalServiceContext } from "@nsealr/client";
import { type AccountDescriptor } from "@nsealr/policy";
import { type SerialLinePortOpener } from "@nsealr/transport";
export declare const SERVICE_ACCOUNT_STORE_FORMAT = "nsealr-service-account-store-v0";
export declare const MAX_SERVICE_ACCOUNT_STORE_JSON_BYTES: number;
export declare const MAX_SERVICE_ACCOUNT_STORE_ACCOUNTS = 256;
export type ServiceAccountStore = {
    format: typeof SERVICE_ACCOUNT_STORE_FORMAT;
    updated_at: number;
    accounts: AccountDescriptor[];
    contains_secret_material: false;
};
export type ServiceContextFileOptions = {
    grantStorePath?: string;
    accountStorePath?: string;
    routeDriverStorePath?: string;
    storageApprovalPath?: string;
    openSerialLinePort?: SerialLinePortOpener;
    /** An application-owned current adapter/session observation provider. Paths
     * and a static account store alone do not establish current compatibility. */
    signerCompatibility?: LocalServiceContext["signerCompatibility"];
    monotonicNow?: LocalServiceContext["monotonicNow"];
    now?: number;
};
export declare function parseServiceAccountStore(value: unknown): ServiceAccountStore;
export declare function loadServiceContextFromFiles(options: ServiceContextFileOptions): LocalServiceContext;
export declare function contextArgsFromCliArgs(args: string[]): ServiceContextFileOptions;
