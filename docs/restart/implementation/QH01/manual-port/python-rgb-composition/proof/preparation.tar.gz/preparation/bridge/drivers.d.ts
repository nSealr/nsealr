import { type SignerRequestDispatcher } from "@nsealr/client";
import { type RouteType } from "@nsealr/policy";
import { type SerialLinePortOpener } from "@nsealr/transport";
export declare const SERVICE_ROUTE_DRIVER_STORE_FORMAT = "nsealr-service-route-driver-store-v0";
export declare const MAX_SERVICE_ROUTE_DRIVER_STORE_JSON_BYTES: number;
export declare const MAX_SERVICE_ROUTE_DRIVERS = 64;
export declare const MAX_SERIAL_LINE_PATH_LENGTH = 512;
export declare const MAX_SERIAL_LINE_IGNORED_LINES = 128;
export declare const MAX_SERIAL_LINE_RESPONSE_TIMEOUT_MS = 120000;
type ServiceSerialLineRouteDriver = {
    account_id: string;
    route_type: Extract<RouteType, "esp32_usb_nip46" | "custom_hardware_wallet">;
    transport: "usb";
    driver: "serial_line";
    serial_line: {
        path: string;
        max_ignored_lines?: number;
        response_timeout_ms?: number;
    };
};
export type ServiceRouteDriver = ServiceSerialLineRouteDriver;
export type ServiceRouteDriverStore = {
    format: typeof SERVICE_ROUTE_DRIVER_STORE_FORMAT;
    updated_at: number;
    contains_secret_material: false;
    routes: ServiceRouteDriver[];
};
export type ServiceRouteDriverOptions = {
    openSerialLinePort: SerialLinePortOpener;
};
export declare function parseServiceRouteDriverStore(value: unknown): ServiceRouteDriverStore;
export declare function createServiceRouteDispatcher(store: ServiceRouteDriverStore, options: ServiceRouteDriverOptions): SignerRequestDispatcher;
export {};
