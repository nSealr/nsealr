#!/usr/bin/env node
import { type LocalServiceContext } from "@nsealr/client";
export declare function runServiceOnce(input: Uint8Array, context?: LocalServiceContext): Uint8Array;
export declare function runServiceOnceAsync(input: Uint8Array, context?: LocalServiceContext): Promise<Uint8Array>;
export declare function runServiceFrames(input: Uint8Array, context?: LocalServiceContext): Uint8Array;
export declare function runServiceFramesAsync(input: Uint8Array, context?: LocalServiceContext): Promise<Uint8Array>;
export declare function runServiceStdio(options?: {
    context?: LocalServiceContext;
    inputFd?: number;
    outputFd?: number;
}): void;
export declare function runServiceStdioAsync(options?: {
    context?: LocalServiceContext;
    inputFd?: number;
    outputFd?: number;
}): Promise<void>;
export declare function runServiceCli(args: string[]): Promise<void>;
