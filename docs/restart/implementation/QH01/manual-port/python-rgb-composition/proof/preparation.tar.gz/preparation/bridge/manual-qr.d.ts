import { type SignerRequestDispatcher } from "@nsealr/client";
import { type RouteType } from "@nsealr/policy";
type ManualQrRouteType = Extract<RouteType, "raspberry_qr_vault" | "esp32_qr_vault">;
export type ManualQrPortControl = {
    account_id: string;
    route_type: ManualQrRouteType;
    request_id: string;
    expected_public_key: string;
    /** Host currentness only. A port delaying presentation must call this again
     * immediately before exposing bytes; it is never physical consent/recall. */
    before_present: () => void;
    abort_signal: AbortSignal;
    /** The injected port must enforce these before its own allocation/decoding. */
    maximum_response_frame_bytes: number;
    maximum_response_json_bytes: number;
};
/** Trusted, exclusively owned software port. present settles after actual
 * presentation; scan returns ONE original static envelope (null means cancel).
 * close resolves only after callbacks/buffers/native resources are reusable.
 * A rejected open/close cannot establish quiescence and quarantines this owner.
 * No camera, optical, native-memory or device-cancellation proof is implied. */
export type ManualQrPort = {
    present(envelope: string): void | Promise<void>;
    scan(): Promise<string | null>;
    close(): void | Promise<void>;
};
/** Service-only, explicitly injected experimental static codec. Do not share
 * its physical port through another factory. No default route/readiness is set.
 * The actual client retains account/capability/deadline/pending and independent
 * expected-key/canonical-ID/signature checks; this is not another lifecycle. */
export declare function createManualQrRouteDispatcher(options: {
    account_id: string;
    route_type: ManualQrRouteType;
    openPort: (control: ManualQrPortControl) => ManualQrPort | Promise<ManualQrPort>;
}): SignerRequestDispatcher;
export {};
