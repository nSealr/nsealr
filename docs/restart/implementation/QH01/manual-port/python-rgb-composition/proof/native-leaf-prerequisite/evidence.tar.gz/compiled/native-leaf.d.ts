import type { spawn } from "node:child_process";
export interface NativeLeafDependencies {
    root: string;
    spawn: typeof spawn;
    timers: {
        setTimeout: typeof setTimeout;
        clearTimeout: typeof clearTimeout;
    };
    onSpawn(): void;
    onCollected(): void;
    reportSettlement(record: Record<string, unknown>): void;
    reportObservation(record: unknown): void;
}
export declare function createPrepareNative(dependencies: NativeLeafDependencies): (hold?: boolean, env?: NodeJS.ProcessEnv, syntheticArgv?: string[]) => Promise<{
    dispose: () => Promise<void>;
    isCollected: () => boolean;
    ended: Promise<{
        code: number | null;
        signal: NodeJS.Signals | null;
    }>;
    pid: number | undefined;
    inputBytes: () => number;
    killOwned: () => boolean;
    send(frame: string, onHeld?: (release: () => void) => void): Promise<string>;
}>;
