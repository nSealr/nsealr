"""Transparent native-only observation of existing exchange.build_artifact.
Adapted from accepted reviews/QP01-owner-cold/provision-observer.py; no runtime call.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys
source, evidence = map(Path, sys.argv[1:3])
path = source / 'docs/restart/implementation/QP01/request-engine/exchange.py'
spec = importlib.util.spec_from_file_location('reviewed_native_producer', path)
producer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(producer)
actual_run = subprocess.run
calls = []
def observe(*args, **kwargs):
    result = actual_run(*args, **kwargs)
    assert args[0][:2] == ['cargo', 'build']
    assert kwargs['cwd'] == source and kwargs['check'] is True
    raw = result.stdout.encode('utf-8')
    (evidence / 'cargo.stdout.jsonl').write_bytes(raw)
    calls.append({'argv': args[0], 'cwd': str(kwargs['cwd']), 'exit_code': result.returncode,
                  'wait': 'subprocess.run completed after actual Cargo wait; raw wait not exposed',
                  'stdout_sha256': hashlib.sha256(raw).hexdigest()})
    return result
producer.subprocess.run = observe
command = ['cargo', 'build', '-p', 'nsealr-pi-engine-fixture', '--locked', '--offline',
           '--release', '--message-format=json']
try:
    library, digest, before = producer.build_artifact(command, producer.SOURCE,
        source / 'crates/nsealr-pi-engine-fixture/Cargo.toml', 'nsealr_pi_engine_fixture', 'cdylib')
finally:
    producer.subprocess.run = actual_run
    (evidence / 'cargo-calls.json').write_text(json.dumps(calls, indent=2) + '\n')
assert digest != '98d0a76522e05bbdd6173a9046ccc990407195313fda8e393b857cc666b5b02f'
record = {'library': str(library), 'sha256': digest, 'bytes': library.stat().st_size,
          'input_before': before, 'input_after': producer.source_binding(),
          'producer_source_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
          'actual_build_commands': len(calls), 'role': 'new corrected closure actual native ELF; not executed; no reproducibility claim'}
assert record['input_before'] == record['input_after'] and len(calls) == 1
(evidence / 'actual-library.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
