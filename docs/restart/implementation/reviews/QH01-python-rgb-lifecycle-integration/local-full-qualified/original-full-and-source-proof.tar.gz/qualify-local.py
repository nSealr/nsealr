import importlib.util,json,sys
from pathlib import Path
log,head,repo,output=sys.argv[1:]
source=Path(repo)/"docs/restart/implementation/QP01/host-coordinator/cold-delivery/verify-cold-capture.py"
spec=importlib.util.spec_from_file_location("completed_local_source",source)
checker=importlib.util.module_from_spec(spec); spec.loader.exec_module(checker)
result=checker.verify_product(Path(log).read_bytes(),head,repo)
with Path(output).open("x") as f: json.dump(result,f,indent=2); f.write("\n")
print(json.dumps({"local_source_addon":True,"hosted_claim":False,"first":result["first_owner_cases"],"owner_rows":result["python_owner_telemetry_rows"],"builds":result["qh01_build_records_verified"],"negative_lifecycle":len(result["qh01_automatic_lifecycle_cases"]),"Pi_tests":result["actual_full_Pi_tests"]}))
