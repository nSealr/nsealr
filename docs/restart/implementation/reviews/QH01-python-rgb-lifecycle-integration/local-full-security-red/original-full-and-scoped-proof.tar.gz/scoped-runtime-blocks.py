import importlib.util,json,re,sys
from pathlib import Path
log,head,repo,output=sys.argv[1:]
source=Path(repo)/"docs/restart/implementation/QP01/host-coordinator/cold-delivery/verify-cold-capture.py"
spec=importlib.util.spec_from_file_location("qualified_capture",source)
c=importlib.util.module_from_spec(spec); spec.loader.exec_module(c)
raw=Path(log).read_bytes(); lines=[re.sub(r"^\d{4}-\d\d-\d\dT\S+Z ?","",s) for s in raw.decode().splitlines()]
objects=[]; decoder=json.JSONDecoder()
for i,line in enumerate(lines):
 if line.startswith("{"):
  try: value,_=decoder.raw_decode("\n".join(lines[i:]))
  except json.JSONDecodeError: continue
  if isinstance(value,dict): objects.append(value)
builds=[o for o in objects if o.get("role")=="public fixture build, not hardware qualification"]
assert len(builds)==1
first=c.verify_first(objects,builds[0],head,repo)
owner=c.verify_python_owner(objects,first["worker_build"],head,repo)
positive=c.verify_qh01_composition(objects,lines,first["worker_build"],head,repo,full_product=True)
lifecycle=c.verify_qh01_lifecycle(objects)
result={"role":"Scoped existing non-audit oracle blocks on FAILED original full run; NOT complete CI/source-addon acceptance", "source_head":head, "full_run_exit":2, "full_run_passed":False, "known_failed_target":"cargo-deny/RUSTSEC-2026-0387 crypto-bigint0.7.5", "first":first,"python_owner":owner,"positive":positive,"lifecycle":lifecycle,"new_product_processes":0}
with Path(output).open("x") as f: json.dump(result,f,indent=2); f.write("\n")
print(json.dumps({"scoped_blocks_pass":True,"whole_gate_pass":False,"first_cases":first["first_owner_cases"],"owner_rows":owner["python_owner_telemetry_rows"],"build_records":positive["qh01_build_records_verified"],"lifecycle_cases":len(lifecycle["qh01_automatic_lifecycle_cases"])}))
