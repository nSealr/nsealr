from pathlib import Path
import importlib.util,json,sys
log,head,repo=sys.argv[1:]
path=Path(repo)/"docs/restart/implementation/QP01/host-coordinator/cold-delivery/verify-cold-capture.py"
spec=importlib.util.spec_from_file_location("current_source_addon",path)
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
print(json.dumps(module.verify_product(Path(log).read_bytes(),head,repo),indent=2))
