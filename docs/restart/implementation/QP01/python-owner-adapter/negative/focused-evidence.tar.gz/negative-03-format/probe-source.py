import unittest
from test_qr_owner_adapter_lifecycle import save
class Probe(unittest.TestCase):
    def test_a(self): save("format-a","record","STDLIB_MERGED_STREAM_ZERO_OW")
    def test_b(self): save("format-b","record","STDLIB_MERGED_STREAM_ZERO_OW")
unittest.main()
