typedef int (*secp256k1_nonce_function_hardened)(
    unsigned char *nonce32,
    const unsigned char *msg,
    size_t msglen,
    const unsigned char *key32,
    const unsigned char *xonly_pk32,
    const unsigned char *algo,
    size_t algolen,
    void *data
);

extern const secp256k1_nonce_function_hardened secp256k1_nonce_function_bip340;

typedef struct {
    unsigned char magic[4];
    secp256k1_nonce_function_hardened noncefp;
    void* ndata;
} secp256k1_schnorrsig_extraparams;

int secp256k1_schnorrsig_sign(
    const secp256k1_context* ctx,
    unsigned char *sig64,
    const unsigned char *msg32,
    /* Not really void: secp256k1_keypair */
    const void *keypair,
    const unsigned char *aux_rand32
);
int secp256k1_schnorrsig_sign_custom(
    const secp256k1_context* ctx,
    unsigned char *sig64,
    const unsigned char *msg,
    size_t msglen,
    /* Not really void: secp256k1_keypair */
    const void *keypair,
    secp256k1_schnorrsig_extraparams *extraparams
);
int secp256k1_schnorrsig_verify(
    const secp256k1_context* ctx,
    const unsigned char *sig64,
    const unsigned char *msg,
    size_t msglen,
    /* Not really void: secp256k1_xonly_pubkey */
    const void *xonly_pubkey
);
