import datetime, hashlib, json, os, pathlib, subprocess, time, threading, resource
ROOT=pathlib.Path("/home/tux/nsealr/.restart-tools/mac-resume-2026-10-25/p4-probe")
BASEPY="/home/tux/nsealr/.restart-tools/goal/r00/tools/baseline/.work/final/.tools/python/bin/python3"
ADMISSION=json.loads((ROOT/"execution/root-admission.json").read_text())
ENV=os.environ.copy()
for k in list(ENV):
    if k.startswith(("IDF_","ESP_","PIP_","PYTHON")):ENV.pop(k)
ENV.update(ADMISSION["controlled_environment"])
ENV["TMPDIR"]=str(ROOT/"cache/tmp")
def sha(p):
    h=hashlib.sha256()
    with open(p,"rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):h.update(b)
    return h.hexdigest()
def write(path,value):
    path=pathlib.Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2)+"\n")
def resource_snapshot(label):
    out={"label":label,"utc":datetime.datetime.now(datetime.timezone.utc).isoformat()}
    for k,a in [("df",["df","-B1",str(ROOT)]),("free",["free","-b"]),("du",["du","-sb",str(ROOT)])]:
        r=subprocess.run(a,capture_output=True,text=True);out[k]={"argv":a,"exit":r.returncode,"stdout":r.stdout,"stderr":r.stderr}
    write(ROOT/"execution"/(label+"-resources.json"),out)
    return out
def run(label,argv,cwd=None,expected=0,env_extra=None,timeout=None):
    folder=ROOT/"execution"/label
    base=folder
    attempt=1
    while folder.exists():
        attempt+=1;folder=pathlib.Path(str(base)+"-"+str(attempt).zfill(2))
    folder.mkdir(exist_ok=False)
    env=ENV.copy()
    if env_extra:env.update(env_extra)
    rec={"argv":list(map(str,argv)),"cwd":str(cwd or ROOT),"controlled_environment":{k:env.get(k) for k in list(ADMISSION["controlled_environment"])+["TMPDIR"]},"extra_environment":env_extra or {},"expected_exit":expected,"start_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"time_wrapper":[],"resource_note":"Python monotonic elapsed plus sampled process-group aggregateRSS; no external GNUtime available","role":"setup/configure, not an application build unless label explicitly app-build"}
    write(folder/"command.json",rec)
    print("START",label,flush=True)
    peak=0; samples=0; start=time.monotonic()
    with open(folder/"stdout.log","w") as so,open(folder/"stderr.log","w") as se:
        proc=subprocess.Popen(rec["time_wrapper"]+rec["argv"],cwd=rec["cwd"],env=env,stdout=so,stderr=se,start_new_session=True)
        while proc.poll() is None:
            try:
                ps=subprocess.run(["ps","-eo","pgid=,rss="],capture_output=True,text=True)
                rss=sum(int(z[1])*1024 for line in ps.stdout.splitlines() if len(z:=line.split())==2 and int(z[0])==proc.pid)
                peak=max(peak,rss);samples+=1
                if timeout and time.monotonic()-start>timeout:
                    import signal
                    os.killpg(proc.pid,signal.SIGTERM)
                    raise RuntimeError("bounded command timeout: "+label)
            except (ValueError,ProcessLookupError):pass
            time.sleep(.5)
        rec.update(exit=proc.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),seconds=time.monotonic()-start,process_group_RSS_peak_bytes=peak,max_child_RSS_cumulative_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,RSS_sampling_count=samples,RSS_method="sum RSS by process group every0.5s; shared pages counted multiple times; resource.getrusage max-child is cumulative for this phase process and labeled accordingly",stdout_sha256=sha(folder/"stdout.log"),stderr_sha256=sha(folder/"stderr.log"))
    write(folder/"result.json",rec)
    print("END",label,"exit",proc.returncode,"seconds",round(rec["seconds"],2),"peak_RSS_sum",peak,flush=True)
    if expected is not None and proc.returncode!=expected:
        print("STDOUT_TAIL",(folder/"stdout.log").read_text(errors="replace")[-2000:],flush=True)
        print("STDERR_TAIL",(folder/"stderr.log").read_text(errors="replace")[-4000:],flush=True)
        raise RuntimeError("command failed: "+label)
    return rec

