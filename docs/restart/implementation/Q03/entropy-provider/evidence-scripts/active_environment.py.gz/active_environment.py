from common import *
import common
NEWENV=ROOT/"python-env-uv"
PY=str(NEWENV/"bin/python")
UV=str(ROOT/"tools/uv/0.11.28/uv")
ACT=ENV.copy()
for key in list(ACT):
    if key.startswith(("PIP_","UV_")) or key=="VIRTUAL_ENV":ACT.pop(key)
ACT.update({"IDF_PYTHON_ENV_PATH":str(NEWENV),"PYTHON":PY,"VIRTUAL_ENV":str(NEWENV),"UV_CACHE_DIR":str(ROOT/"cache/uv"),"UV_PYTHON_DOWNLOADS":"never","PYTHONPYCACHEPREFIX":str(ROOT/"cache/pycache-uv"),"TMPDIR":str(ROOT/"cache/tmp")})
toolpaths=[
 ROOT/"tools/tools/riscv32-esp-elf-gdb/17.1_20260402/riscv32-esp-elf-gdb/bin",
 ROOT/"tools/tools/riscv32-esp-elf/esp-15.2.0_20251204/riscv32-esp-elf/bin",
 ROOT/"tools/tools/cmake/4.0.3/bin",
 ROOT/"tools/tools/openocd-esp32/v0.12.0-esp32-20260424/openocd-esp32/bin",
 ROOT/"tools/tools/ninja/1.12.1",
 ROOT/"src/esp-idf/tools"]
ACT["PATH"]=":".join([str(NEWENV/"bin")]+list(map(str,toolpaths))+["/usr/bin","/bin"])
ACT["OPENOCD_SCRIPTS"]=str(ROOT/"tools/tools/openocd-esp32/v0.12.0-esp32-20260424/openocd-esp32/share/openocd/scripts")
ACT["ESP_ROM_ELF_DIR"]=str(ROOT/"tools/tools/esp-rom-elfs/20241011")
ACT["ESP_IDF_VERSION"]="6.0"
common.ENV=ACT
def freeze_active(label):
    keys=sorted(set(ADMISSION["controlled_environment"])|{"VIRTUAL_ENV","UV_CACHE_DIR","UV_PYTHON_DOWNLOADS","TMPDIR","OPENOCD_SCRIPTS","ESP_ROM_ELF_DIR","ESP_IDF_VERSION"})
    write(ROOT/"execution"/(label+"-environment.json"),{"environment":{k:ACT.get(k) for k in keys},"common_helper_sha256":sha(ROOT/"scripts/common.py"),"active_environment_source_sha256":sha(ROOT/"scripts/active_environment.py"),"script_sha256":sha(__file__),"root_uv_amendment_admission":str(ROOT/"execution/root-uv-amendment-admission.json")})

